let x=0;
  
 function increment(){
    x++;
    document.getElementById('demo').innerHTML= x;
 } 
 function decrement(){
    x--;
    document.getElementById('demo').innerHTML= x;
 }

 


