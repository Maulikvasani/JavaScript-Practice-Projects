    <script>
        let day = "Tuesday"; // Change this to any weekday (e.g., "Monday", "Friday")

        switch (day) {
            case "Monday":
                document.getElementById('demo').innerHTML = "It's the start of the week!";
                break;
            case "Tuesday":
                document.getElementById('demo').innerHTML = "It's Tuesday!";
                break;
            case "Wednesday":
                document.getElementById('demo').innerHTML = "Midweek already!";
                break;
            case "Thursday":
                document.getElementById('demo').innerHTML = "Almost Friday!";
                break;
            case "Friday":
                document.getElementById('demo').innerHTML = "Weekend is near!";
                break;
            case "Saturday":
                document.getElementById('demo').innerHTML = "Enjoy your Saturday!";
                break;
            case "Sunday":
                document.getElementById('demo').innerHTML = "Relax, it's Sunday!";
                break;
            default:
                document.getElementById('demo').innerHTML = "Invalid day!";
        }
    </script>


