function calculateTicket() {
  let x = document.getElementById('ageInput').value;
  x = parseInt(x);
  if (x <= 5) { 
      document.getElementById('age').innerHTML = "5 RS";
  } else if (x <= 20) {
      document.getElementById('age').innerHTML = "10 RS";
  } else if (x <= 40) {
      document.getElementById('age').innerHTML = "15 RS";
  } else if (x <= 60) {
      document.getElementById('age').innerHTML = "20 RS";
  } else if (x <= 100) {
      document.getElementById('age').innerHTML = "30 RS";
  } else {
      document.getElementById('age').innerHTML = "Ticket Nai Milega";
  }
}
