let x="yellow";

  if(x=="red"){
    document.getElementById('demo').innerHTML="stop";
  }
  else if(x=="green"){
    document.getElementById('demo').innerHTML="go";
  }
   else if(x=="yellow"){
    document.getElementById('demo').innerHTML="wait";
   }
 else{
    document.getElementById('demo').innerHTML="not working";
 }